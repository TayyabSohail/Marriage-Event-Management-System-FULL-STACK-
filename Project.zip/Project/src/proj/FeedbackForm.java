package proj;

import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;

public class FeedbackForm extends JFrame {

	private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextArea textAreaFeedback;
    private JRadioButton rdbtn1, rdbtn2, rdbtn3, rdbtn4, rdbtn5;
    private String customerId; // Assuming customer ID is a String, you can modify it accordingly
    private String orderId; // Assuming order ID is a String, you can modify it accordingly

    // Feedback object to store information
    private Feedback feedback;

    /**
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FeedbackForm frame = new FeedbackForm("123", "456"); // Replace with actual customer and order IDs
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    /**
     * Create the frame.
     */
    public FeedbackForm(String customerId, String orderId) {
    	 this.customerId = customerId;
         this.orderId = orderId;

         // Initialize Feedback object with customer and order IDs
         this.feedback = new Feedback(customerId, orderId);

         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(243, 151, 130));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblFeedback = new JLabel("FEEDBACK");
        lblFeedback.setForeground(new Color(0, 0, 0));
        lblFeedback.setHorizontalAlignment(SwingConstants.CENTER);
        lblFeedback.setFont(new Font("Arial", Font.BOLD, 18));
        lblFeedback.setBounds(10, 10, 414, 20);
        contentPane.add(lblFeedback);

        JLabel lblCustomerId = new JLabel("Customer ID: " + customerId);
        lblCustomerId.setFont(new Font("Arial", Font.PLAIN, 14));
        lblCustomerId.setForeground(new Color(255, 255, 255));
        lblCustomerId.setBounds(10, 40, 150, 20);
        contentPane.add(lblCustomerId);

        JLabel lblOrderId = new JLabel("Order ID: " + orderId);
        lblOrderId.setFont(new Font("Arial", Font.PLAIN, 14));
        lblOrderId.setForeground(new Color(255, 255, 255));
        lblOrderId.setBounds(200, 40, 150, 20);
        contentPane.add(lblOrderId);

        textAreaFeedback = new JTextArea();
        textAreaFeedback.setBounds(10, 70, 414, 70);
        contentPane.add(textAreaFeedback);

        JLabel lblStars = new JLabel("Stars:");
        lblStars.setFont(new Font("Arial", Font.PLAIN, 14));
        lblStars.setForeground(new Color(255, 255, 255));
        lblStars.setBounds(10, 150, 60, 20);
        contentPane.add(lblStars);

        JRadioButton[] radioButtons = new JRadioButton[5];
        for (int i = 0; i < 5; i++) {
            radioButtons[i] = new JRadioButton(String.valueOf(i + 1));
            radioButtons[i].setBounds(76 + i * 43, 150, 41, 23);
            contentPane.add(radioButtons[i]);
        }

        JButton btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(335, 170, 89, 23);
        contentPane.add(btnSubmit);
        btnSubmit.addActionListener(e -> {
            // Example: Print customer and order IDs from Feedback object
            System.out.println("Customer ID: " + feedback.getCustomerId());
            System.out.println("Order ID: " + feedback.getOrderId());

            // Use FeedbackController to submit feedback
            FeedbackController feedbackController = new FeedbackController(customerId, orderId);
            feedbackController.submitFeedback(textAreaFeedback.getText(), getSelectedStars(radioButtons));

            // Close the form
            dispose();
        });
    }
    private int getSelectedStars(JRadioButton[] radioButtons) {
        for (int i = 0; i < radioButtons.length; i++) {
            if (radioButtons[i].isSelected()) {
                // Assuming stars are 1-indexed, so add 1 to the index
                return i + 1;
            }
        }
        return 0;  // Return 0 if no stars are selected
    }
}
