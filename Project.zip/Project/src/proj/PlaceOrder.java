package proj;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFrame;  // Import JFrame
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class PlaceOrder extends JFrame {  // Extend JFrame instead of JPanel

   // private String pofId;
   // private String orderId;

   // Order newOrder;   // convert this into an array of orders later on 
    private JTextField capacityField;
    private JTextField Date_label;

    public PlaceOrder() {
    	
        
       // newOrder = new Order();

        getContentPane().setLayout(null);

        // Display provided pof_id and order_id
        
      
        System.out.println(Controller.getInstance().getCustomer().selected_portfolio.portfolio_id);
      
        // Add components for the "Place Order" panel
        JLabel orderDetailsLabel = new JLabel("Order Details:");
        orderDetailsLabel.setBounds(10, 177, 100, 20);
        getContentPane().add(orderDetailsLabel);

        final JTextField orderDetailsField = new JTextField();
        orderDetailsField.setBounds(126, 178, 283, 59);
        getContentPane().add(orderDetailsField);

        JButton confirmOrderButton = new JButton("CONFIRM ORDER");
        confirmOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get user inputs
            	
            // 	System.out.println(Controller.getInstance().getCustomer().selected_portfolio.portfolio_id);
            	
                String orderDetails = orderDetailsField.getText();
                int req_capacity =0 ;
                
            
                	String selectedText = "";
                     selectedText = capacityField.getText();
                    

                     if (selectedText != null && !selectedText.isEmpty()) {
                         try {
                             req_capacity = Integer.parseInt(selectedText);
                             // Use the parsed value here
                         } catch (NumberFormatException h) {
                             // Handle the exception (e.g., log, provide a default value)
                             h.printStackTrace();
                         }
                     } else {
                         // Handle empty or null string
                    	 req_capacity =0 ;
                     }

                System.out.println(req_capacity);
                
                
                 
                
               // System.out.println(selectedText);
                
                //input required capacity done 
                // input order type  done
                // input order details done 
                // input delivery date 
               // newOrder.setOrderDetails(orderDetails);
               // newOrder.setCus_id(Customer_loggedin.id);
                //newOrder.setPofID(Customer_loggedin.selected_portfolio.portfolio_id);
                //newOrder.setReq_capacity( req_capacity);
                //newOrder.setType(Customer_loggedin.selected_portfolio.Type);
                              
                // Create an Order OBJECT and insert the order
                 //Order order = new Order();
                // order.insertOrder();
                
                
                String delivery_date = Date_label.getText();
                boolean date_check = Controller.getInstance().getCustomer().Owd.isValidDate(delivery_date, "yyyy-MM-dd");
                boolean success = false; 
                
                if (date_check == false)
                {
                	JOptionPane.showMessageDialog(null, "Enter a Valid Date format");
                	return;
                }
                else
                {
                
                	success = Controller.getInstance().getCustomer().placeOrder(orderDetails, req_capacity , delivery_date );
               
                }
               if (success)
               {
            	      //win
            	   
               }
               else 
               {
            	      // not win
               }
                // check krra houn ONLY
                //System.out.println("Order Placed! Order ID: " + newOrder.order_id);
            }
        });
        confirmOrderButton.setBounds(198, 248, 150, 30);
        getContentPane().add(confirmOrderButton);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false); // Hide the PlaceOrder frame
            }
        });
        backButton.setBounds(700, 10, 80, 30);
        getContentPane().add(backButton);
        
        capacityField = new JTextField();
        capacityField.setBounds(126, 47, 125, 20);
        getContentPane().add(capacityField);
        capacityField.setColumns(10);
        
        JLabel lblNewLabel = new JLabel("Required Capacity:");
        lblNewLabel.setBounds(10, 50, 125, 14);
        getContentPane().add(lblNewLabel);
        
        JLabel pofIdLabel_1 = new JLabel("Maximum Capacity: " + Controller.getInstance().getCustomer().selected_portfolio.getcapacity());
        pofIdLabel_1.setBounds(334, 15, 200, 20);
        getContentPane().add(pofIdLabel_1);
        
        JLabel lblNewLabel_1 = new JLabel("Portfolio Name: ");
        lblNewLabel_1.setBounds(10, 25, 100, 14);
        getContentPane().add(lblNewLabel_1);
        
        JLabel Pof_ID = new JLabel(Controller.getInstance().getCustomer().selected_portfolio.getpof_name());
        Pof_ID.setBounds(126, 25, 135, 14);
        getContentPane().add(Pof_ID);
        
        JLabel PerPerson = new JLabel("Per Person Budget: " + Controller.getInstance().getCustomer().selected_portfolio.getpricing());
        PerPerson.setBounds(334, 47, 200, 20);
        getContentPane().add(PerPerson);
        
        Date_label = new JTextField();
        Date_label.setToolTipText("");
        Date_label.setBounds(126, 96, 125, 20);
        getContentPane().add(Date_label);
        Date_label.setColumns(10);
        
        JLabel lblNewLabel_2 = new JLabel("Delivery Date: ");
        lblNewLabel_2.setBounds(10, 99, 80, 14);
        getContentPane().add(lblNewLabel_2);
        
        JLabel lblNewLabel_3 = new JLabel(" * YYYY-MM-DD");
        lblNewLabel_3.setBounds(126, 127, 76, 14);
        getContentPane().add(lblNewLabel_3);

        // Set frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(581, 328); // Set your preferred size
        setLocationRelativeTo(null); // Center the frame on the screen
        setTitle("Place Orders"); // Set your title
        setResizable(false); // Optional: Set whether the frame is resizable
        setVisible(true); // Make the frame visible
    }
}