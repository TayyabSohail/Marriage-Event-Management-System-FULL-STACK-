package proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Vendor extends User {

    private Portfolio mypof = null;

    Vendor() {
        mypof = new Portfolio();
    }

    public Portfolio getpof() {
        return mypof;
    }

    // Add the getId and getName methods
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void fetch_from_db(String id) { 
        this.id = id;

        String url = "jdbc:mysql://localhost:3306/project";
        String username = "root";
        String password = "1234";

        // Fetching the rest of the information from the database
        String query = "SELECT * FROM vendor WHERE Id = '" + this.id + "';";

        try (Connection con = DriverManager.getConnection(url, username, password)) {
            try (Statement stmt = con.createStatement()) {
                ResultSet rt = stmt.executeQuery(query);

                while (rt.next()) {
                    this.id = rt.getString("Id");
                    this.name = rt.getString("Name");
                    this.Contact = rt.getString("Contact");
                    this.CNIC = rt.getString("CNIC");
                }
            }
        } catch (SQLException g) {
            g.printStackTrace();
        }
    }
}
