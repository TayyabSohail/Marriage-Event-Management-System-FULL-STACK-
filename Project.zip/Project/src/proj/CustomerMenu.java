package proj;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

public class CustomerMenu extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTabbedPane tabbedPane;
    
   // private Cus Cus_loggedin = new Cus();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CustomerMenu frame = new CustomerMenu();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
 
    /**
     * Create the frame.
     */
    public CustomerMenu() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 938, 625); // Increase the width and height

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Create a JTabbedPane
        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setBounds(10, 11, 814, 529); // Increase the width and height
        contentPane.add(tabbedPane);
        
                //SearchVendor searchVendorPanel = new SearchVendor();
                //tabbedPane.addTab("Search Vendors", null, searchVendorPanel, null);
        // No need for setting layout to null for JPanel components
        // searchVendorPanel.setLayout(null);

        // Example: Adding another JPanel to the JTabbedPane
        JPanel panel2 = new JPanel();
        tabbedPane.addTab("View Orders", null, panel2, null);

        JPanel panel3 = new JPanel();
        tabbedPane.addTab("Notifications", null, panel3, null);
        
       // SearchByFilters SearchbyFilterspanel = new SearchByFilters();
        //tabbedPane.addTab("SearchByFilters", null, SearchbyFilterspanel, null);
    }
}
