package proj;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ViewOrders extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel tableModel;

    /**
     * Create the panel.
     */
    public ViewOrders() {
        setLayout(null);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Order ID");
        tableModel.addColumn("PortFolio ID");
        tableModel.addColumn("Delivery Date");
        tableModel.addColumn("Order Details");
        tableModel.addColumn("Order Status");
        tableModel.addColumn("Required Cap");
        tableModel.addColumn("Order Bill");
        tableModel.addColumn("Type");

        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(39, 62, 647, 336);
        add(scrollPane);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tableModel.setRowCount(0);

                ArrayList<String[]> rows = Controller.getInstance().getCustomer().ViewOrder();

                for (String element[] : rows) {
                    tableModel.addRow(element);
                }

                tableModel.fireTableDataChanged();
            }
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    Controller.getInstance().getCustomer().Owd.getPaymentObj().setOrderId((String) table.getValueAt(selectedRow, 0));
                    Controller.getInstance().getCustomer().Owd.setPofID((String) table.getValueAt(selectedRow, 1));
                    Controller.getInstance().getCustomer().Owd.getPaymentObj().setPayStatus((String) table.getValueAt(selectedRow, 4));
                    Controller.getInstance().getCustomer().Owd.getPaymentObj().setPayAmount(Double.parseDouble((String) table.getValueAt(selectedRow, 6)));
                }
            }
        });

        refreshButton.setBounds(23, 11, 146, 29);
        add(refreshButton);

        JButton btnProceedToPayment = new JButton("Proceed To Payment");
        btnProceedToPayment.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String alreadyPaid = "COMPLETED";
                int result = alreadyPaid.compareTo(Controller.getInstance().getCustomer().Owd.getPaymentObj().getPayStatus());

                if (result == 0) {
                    JOptionPane.showMessageDialog(null, "YOU HAVE ALREADY PAID", "Already Paid", JOptionPane.ERROR_MESSAGE);
                    Controller.getInstance().getCustomer().Owd.emptyOrder();
                } else {
                    PaymentForm paymentForm = new PaymentForm();
                    paymentForm.setVisible(true);
                }
            }
        });
        btnProceedToPayment.setBounds(459, 430, 203, 29);
        add(btnProceedToPayment);

        JButton btnGiveFeedback = new JButton("Give Feedback");
        btnGiveFeedback.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Payment paymentObj = Controller.getInstance().getCustomer().Owd.getPaymentObj();
                String paymentStatus = paymentObj.getPayStatus();

                if ("COMPLETED".equals(paymentStatus)) {
                    FeedbackForm feedbackForm = new FeedbackForm(
                            Controller.getInstance().getCustomer().getCustomerId(),
                            paymentObj.getOrderId()
                    );
                    feedbackForm.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "YOU NEED TO COMPLETE PAYMENT FIRST", "", JOptionPane.ERROR_MESSAGE);
                    Controller.getInstance().getCustomer().Owd.emptyOrder();
                }
            }
        });

        btnGiveFeedback.setBounds(231, 430, 203, 29);
        add(btnGiveFeedback);
    }
}
