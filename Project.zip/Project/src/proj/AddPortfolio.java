

// AddPortfolio.java
package proj;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class AddPortfolio extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldVenId;
    private JTextField textFieldPricing;
    private JTextField textFieldDescription;
    private JTextField textFieldCapacity;
    private JTextField textFieldType;
    private DefaultTableModel tableModel;
    private VendorMenu vendorMenu; // New property to store the reference to VendorMenu

    // Constructor
    public AddPortfolio(DefaultTableModel tableModel) {
        this.tableModel = tableModel;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 400);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblAddData = new JLabel("Add Portfolio");
        lblAddData.setFont(new Font("Arial", Font.BOLD, 18));
        lblAddData.setBounds(160, 10, 150, 30);
        contentPane.add(lblAddData);

        JLabel lblVenId = new JLabel("Vendor ID:");
        lblVenId.setBounds(40, 60, 70, 20);
        contentPane.add(lblVenId);

        textFieldVenId = new JTextField();
        textFieldVenId.setBounds(160, 60, 220, 20);
        contentPane.add(textFieldVenId);
        textFieldVenId.setColumns(10);

        JLabel lblPricing = new JLabel("Pricing:");
        lblPricing.setBounds(40, 100, 120, 20);
        contentPane.add(lblPricing);

        textFieldPricing = new JTextField();
        textFieldPricing.setBounds(160, 100, 220, 20);
        contentPane.add(textFieldPricing);
        textFieldPricing.setColumns(10);

        JLabel lblDescription = new JLabel("Description:");
        lblDescription.setBounds(40, 140, 70, 20);
        contentPane.add(lblDescription);

        textFieldDescription = new JTextField();
        textFieldDescription.setBounds(160, 140, 220, 20);
        contentPane.add(textFieldDescription);
        textFieldDescription.setColumns(10);

        JLabel lblCapacity = new JLabel("Capacity:");
        lblCapacity.setBounds(40, 180, 70, 20);
        contentPane.add(lblCapacity);

        textFieldCapacity = new JTextField();
        textFieldCapacity.setBounds(160, 180, 220, 20);
        contentPane.add(textFieldCapacity);
        textFieldCapacity.setColumns(10);

        JLabel lblType = new JLabel("Type:");
        lblType.setBounds(40, 220, 70, 20);
        contentPane.add(lblType);

        textFieldType = new JTextField();
        textFieldType.setBounds(160, 220, 220, 20);
        contentPane.add(textFieldType);
        textFieldType.setColumns(10);

        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(160, 320, 120, 30);
        contentPane.add(btnAdd);

        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addDataToDatabase();
            }
        });
    }

    // Set the reference to VendorMenu
    public void setVendorMenu(VendorMenu vendorMenu) {
        this.vendorMenu = vendorMenu;
    }

    private void addDataToDatabase() {
        try {
            String venId = textFieldVenId.getText();
            double pricing = Double.parseDouble(textFieldPricing.getText());
            String description = textFieldDescription.getText();
            int capacity = Integer.parseInt(textFieldCapacity.getText());
            String type = textFieldType.getText();

            // Generate the new pof_id
            String newPofId = generateNewPofId();

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "INSERT INTO Portfolio (pof_id, Ven_id, Pricing, Description, Capacity, Type) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, newPofId);
            preparedStatement.setString(2, venId);
            preparedStatement.setDouble(3, pricing);
            preparedStatement.setString(4, description);
            preparedStatement.setInt(5, capacity);
            preparedStatement.setString(6, type);

            preparedStatement.executeUpdate();

            // Add the new data to the table model
            String[] rowData = { "false", newPofId, venId, String.valueOf(pricing), description, String.valueOf(capacity), type };
            tableModel.addRow(rowData);

            // Pass the entered data to VendorMenu
            if (vendorMenu != null) {
                vendorMenu.addDataFromAddPortfolio(venId, pricing, description, capacity, type);
            }

            // After adding, you can close the add portfolio page
            dispose();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String generateNewPofId() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "SELECT MAX(CAST(SUBSTRING(pof_id, 5) AS SIGNED)) + 1 AS new_id FROM Portfolio";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            int newId = resultSet.getInt("new_id");

            // Format the new pof_id
            String newPofId = "POF-" + newId;

            resultSet.close();
            preparedStatement.close();
            connection.close();

            return newPofId;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }











    private void fetchDataFromDatabase() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "SELECT * FROM Portfolio";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String pofId = resultSet.getString("pof_id");
                String venId = resultSet.getString("ven_id");
                double pricing = resultSet.getDouble("pricing");
                String description = resultSet.getString("description");
                int capacity = resultSet.getInt("capacity");
                String type = resultSet.getString("Type");

                String[] rowData = {"false", pofId, venId, String.valueOf(pricing), description, String.valueOf(capacity), type};
                tableModel.addRow(rowData);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }








