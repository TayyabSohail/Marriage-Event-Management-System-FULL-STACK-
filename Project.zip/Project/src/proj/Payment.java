package proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Payment {
	
	/*
	payment_id varchar(50) primary key, 
    payment_amount double,
    payment_status enum("Completed","Pending") ,    -- ENUM is used instad of boolean and does not support null values
	payment_details varchar(50),
    order_id varchar(50) ,
    
    */
	
	private String pay_id ; 
	private double pay_amount ; 
	private String pay_status;
	private String pay_details; 
	private String order_id ; 
	
	
	//FEEDBACK OBJECT 
	Feedback feed;
	
	
	Payment ()
	{
		pay_id = "";
		pay_amount = 0 ; 
		pay_status = "PENDING" ; 
		pay_details = "" ; 
		order_id = "";
	
		//feed = new Feedback();
		this.assignID();
	} 
	
	
	
	
	
	public void assignID()
	{
		 String url = "jdbc:mysql://localhost:3306/project";
	        String username = "root";
	        String password = "1234";
	        
	        
	        String separator = "";
	        int unique_num = 0;

	        try (Connection con = DriverManager.getConnection(url, username, password)) {
	       	 	this.pay_id = "PAY-1";
	       	 	
	                try (Statement stmt = con.createStatement()) {
	                    ResultSet rt = stmt.executeQuery(
	                            "SELECT payment_id FROM Payment  ORDER BY payment_id DESC LIMIT 1;");

	                    while (rt.next()) {
	                        pay_id = rt.getString("payment_id");

	                        for (int i = 4; i < pay_id.length(); i++) {
	                            separator += pay_id.charAt(i);
	                        }

	                        unique_num = Integer.parseInt(separator);
	                        unique_num++;
	                       // System.out.println(unique_num);
	                        this.pay_id = "PAY-" + String.valueOf(unique_num);
	                        //System.out.println(pay_id);
	                    }
	                }
	       
	   }catch (SQLException e) {
	       e.printStackTrace();
	   }
	}
	
	
	
	
	
	
	
	public void clearPaymentobj()
	{
		pay_id = "";
		//////FEEDBACK OBJECT CLEAR 
		pay_amount = 0 ; 
		pay_status = "PENDING" ; 
		pay_details = "" ; 
		order_id = "";
	}
	
	
	
	
	
	
	// Setter methods
    public void setPayId(String pay_id) {
        this.pay_id = pay_id;
    }

    public void setPayAmount(double pay_amount) {
        this.pay_amount = pay_amount;
    }

    public void setPayStatus(String pay_status) {
        this.pay_status = pay_status;
    }

    public void setPayDetails(String pay_details) {
        this.pay_details = pay_details;
    }

    public void setOrderId(String order_id) {
        this.order_id = order_id;
    }

    // Getter methods
    public String getPayId() {
        return pay_id;
    }

    public double getPayAmount() {
        return pay_amount;
    }

    public String getPayStatus() {
        return pay_status;
    }

    public String getPayDetails() {
        return pay_details;
    }

    public String getOrderId() {
        return order_id;
    }
    
    
    
    public void makePayment(String Payment_Details , double amount )
    {
    	
    }
    
    
    public boolean amount_valid(double entered , double due)
    {
    	boolean flag = false;
    	if (entered > due)
    	{
    		flag = true;
    	}
    	
    	
    		
    		
    		return flag;
    }
    
    public boolean balance_check(double Amount_entered , double Customer_bal)
			{
		    	boolean flag = true;
		    	if (Amount_entered > Customer_bal)
		    	{
		    		flag = false;
		    	}
		    	
		    	return flag;
			}
    
    
    			public boolean makePayment(double Amount_entered , double Amount_due , double Customer_bal , String Payment_Details) 
    			{
    					double remaining_bal = Customer_bal - Amount_due ;
    					double change  = Amount_entered - Amount_due ; 
    					this.pay_status = "COMPLETED";
    					this.pay_details  = Payment_Details ; 
    					//System.out.println(this.pay_status);
    					Controller.getInstance().getCustomer().Owd.setIsActive(this.pay_status);
    					Controller.getInstance().getCustomer().Owd.setOrder_id(this.order_id);
    					
    					//System.out.println(Controller.getInstance().getCustomer().Owd.isActive);
    					boolean flag = false;
    					//boolean flag_2 = false ; //= void update_status();
    					
    					
    					//flag_1 = update_status();
    					flag = addin_table();
    					
    					
    					
    					
    				return flag ; 
    				
    			}
    			
    			
    			private boolean addin_table() 
    			{
			
    				 String url = "jdbc:mysql://localhost:3306/project";
    			        String username = "root";
    			        String password = "1234";
    			        
    			        boolean flag = false;

    			        try (Connection con = DriverManager.getConnection(url, username, password)) {
    			        	
    			       
    			        //boolean capacity_check  = check_capacity() ;   // this is to check whether the entered exceeds avaliable capacity
    			            String sql = "INSERT INTO Payment (payment_id, order_id, payment_amount, payment_status, payment_details)" +
    			                         "VALUES (?,?, ?, ?, ?)";
    			            
    			            
    			            
    			            	 
    			            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
    			            	pstmt.setString(1, this.pay_id);  
    			            	pstmt.setString(2, this.order_id);
    			                pstmt.setString(3, String.valueOf(this.pay_amount));     /// input from user
    			                pstmt.setString(4, this.pay_status);   // customer id
    			                pstmt.setString(5, this.pay_details);      /// input from user
    			                //pstmt.setString(6, this.isActive);      ///work on how the order is completed think further
    			             
    			               // pstmt.setInt(7,  this.req_capacity);        //input from user
    			                
    			               // pstmt.setString(8, this.type);
    			               // pstmt.setDouble(9, this.order_bill);

    			                int rowsAffected = pstmt.executeUpdate();
    			                if (rowsAffected > 0) {
    			                   // System.out.println("Order placed successfully!");
    			                    flag = true ; 
    			                    
    			                } else {
    			                    //System.out.println("Failed to place order in the table.");
    			                    flag = false; 
    			                    
    			                }
    			            }
    			            
    			            
    			            
    			        } catch (SQLException e) {
    			            e.printStackTrace();  // Log or handle the exception appropriately
    			        }
    			        
							 
							 return flag; 
			    }
    
}