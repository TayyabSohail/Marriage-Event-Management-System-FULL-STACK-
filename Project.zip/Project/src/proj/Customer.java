package proj;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Customer extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private static JTabbedPane tabbedPane;
    private static PlaceOrder placeOrdersPanel; // Declare placeOrdersPanel as a static variable
    private JLabel lblNewLabel;

    /**
     * Launch the application.
     */
   /* public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Customer frame = new Customer();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    */

    /**
     * Create the frame.
     */
    public Customer() {
    	
    	//Cus Customer_loggedin = Controller.getInstance().getCustomer(); // copy constructor
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 850, 600); // Increase the width and height

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Create a JTabbedPane
        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setBounds(10, 11, 814, 529);
        contentPane.add(tabbedPane);

        ///////////////////////////////////////////////////////////

        SearchVendor searchVendorPanel = new SearchVendor();
        searchVendorPanel.setBackground(new Color(232, 127, 110));
        tabbedPane.addTab("Search Vendor", null, searchVendorPanel, null);
        
        ViewOrders ViewOrdersPanel = new ViewOrders();
        ViewOrdersPanel.setBackground(new Color(232, 127, 110));
        tabbedPane.addTab("View Order", null, ViewOrdersPanel, null);
        
        
        ///////////////////////////////////////////////////////////
        // PlaceOrder panel
        // Provide default values for pofId and orderId
        

        
      //  placeOrdersPanel = new PlaceOrder(Customer_loggedin);
        //placeOrdersPanel.setBackground(new Color(232, 127, 110));
        //tabbedPane.addTab("Place Orders", null, placeOrdersPanel, null);
    }

    public static void switchToSearchVendorPanel() {
        tabbedPane.setSelectedIndex(0);
    }

    public static void switchToViewOrdersPanel() {
        tabbedPane.setSelectedIndex(1);
    }
}