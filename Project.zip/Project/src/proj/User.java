package proj;

public  class User {
	
	protected String id;
	protected String name ; 
	//String pass ; 
	protected String CNIC;
	//String CNIC;
	protected String Contact ; 
	
	/// we need to cater for account number too some h
	
	protected double Acc_bal;
	
	User()
	{
		name = ""; 
		//pass = "";
		 CNIC = "";
		 Contact = "";
		Acc_bal = 0;
	}

}
