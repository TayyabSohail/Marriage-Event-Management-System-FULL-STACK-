package proj;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VendorMenu extends JFrame {

    private DefaultTableModel tableModel;
    private JTable table;
    private int selectedRowIndex = -1;
    private Vendor loggedInVendor;
    private JLabel lblVendorId;
    private JLabel lblVendorName;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VendorMenu frame = new VendorMenu(Controller.getInstance().getVendor());
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VendorMenu(Vendor loggedInVendor) {
        this.loggedInVendor = loggedInVendor;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);

        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);

        JPanel myPortfolioPanel = new JPanel();
        myPortfolioPanel.setBackground(new Color(243, 151, 130)); // Set background color
        tabbedPane.addTab("My Portfolio", null, myPortfolioPanel, null);

        JPanel viewOrdersPanel = new JPanel();
        tabbedPane.addTab("View Orders", null, viewOrdersPanel, null);
        initializeViewOrdersPanel(viewOrdersPanel);

        lblVendorId = new JLabel("Vendor ID: " + loggedInVendor.getId());
        lblVendorName = new JLabel("Vendor Name: " + loggedInVendor.getName());

        JButton btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Arial", Font.PLAIN, 18));
        btnAdd.addActionListener(e -> openAddPortfolioPage());

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setFont(new Font("Arial", Font.PLAIN, 18));

        JButton btnDelete = new JButton("Delete");
        btnDelete.setFont(new Font("Arial", Font.PLAIN, 18));

        GroupLayout layout = new GroupLayout(myPortfolioPanel);
        myPortfolioPanel.setLayout(layout);

        JLabel lblHeading = new JLabel("MANAGE PORTFOLIO");
        lblHeading.setFont(new Font("Arial", Font.BOLD, 24));

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Select");
        tableModel.addColumn("Pof_id");
        tableModel.addColumn("Ven_id");
        tableModel.addColumn("Pricing");
        tableModel.addColumn("Description");
        tableModel.addColumn("Capacity");
        tableModel.addColumn("Type");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        GroupLayout.SequentialGroup horizontalGroup = layout.createSequentialGroup();
        horizontalGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(lblVendorId)
                .addComponent(lblVendorName)
                .addComponent(lblHeading)
                .addComponent(scrollPane)
                .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAdd)
                        .addComponent(btnUpdate)
                        .addComponent(btnDelete)));

        GroupLayout.SequentialGroup verticalGroup = layout.createSequentialGroup();
        verticalGroup.addComponent(lblVendorId)
                .addComponent(lblVendorName)
                .addComponent(lblHeading)
                .addComponent(scrollPane)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(btnAdd)
                        .addComponent(btnUpdate)
                        .addComponent(btnDelete));

        layout.setHorizontalGroup(horizontalGroup);
        layout.setVerticalGroup(verticalGroup);

        fetchDataFromDatabase();

        table.getSelectionModel().addListSelectionListener(e -> {
            btnUpdate.setEnabled(table.getSelectedRow() != -1);
            btnDelete.setEnabled(table.getSelectedRow() != -1);
        });

        btnUpdate.addActionListener(e -> {
            int selectedRowIndex = table.getSelectedRow();
            if (selectedRowIndex != -1) {
                String pofId = (String) tableModel.getValueAt(selectedRowIndex, 1);
                String venId = (String) tableModel.getValueAt(selectedRowIndex, 2);
                double pricing = Double.parseDouble(tableModel.getValueAt(selectedRowIndex, 3).toString());
                String description = (String) tableModel.getValueAt(selectedRowIndex, 4);
                int capacity = Integer.parseInt(tableModel.getValueAt(selectedRowIndex, 5).toString());
                String type = (String) tableModel.getValueAt(selectedRowIndex, 6);

                UpdatePage updatePage = new UpdatePage(tableModel, venId, pricing, description, capacity, type, selectedRowIndex);
                updatePage.setVisible(true);

                updatePage.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                    }
                });
            }
        });

        btnDelete.addActionListener(e -> deleteSelectedPortfolio());
    }

	
	 private void initializeViewOrdersPanel(JPanel viewOrdersPanel) {
    viewOrdersPanel.setBackground(new Color(243, 151, 130)); // Set background color

    GroupLayout layout = new GroupLayout(viewOrdersPanel);
    viewOrdersPanel.setLayout(layout);

    JLabel lblHeading = new JLabel("VIEW ORDERS");
    lblHeading.setFont(new Font("Arial", Font.BOLD, 24));

    tableModel = new DefaultTableModel();
    tableModel.addColumn("Order ID");
    tableModel.addColumn("Customer ID");
    tableModel.addColumn("Order Details");
    tableModel.addColumn("Status");

    table = new JTable(tableModel);
    JScrollPane scrollPane = new JScrollPane(table);

    layout.setAutoCreateGaps(true);
    layout.setAutoCreateContainerGaps(true);

    GroupLayout.SequentialGroup horizontalGroup = layout.createSequentialGroup();
    horizontalGroup.addComponent(lblHeading)
            .addComponent(scrollPane);

    GroupLayout.SequentialGroup verticalGroup = layout.createSequentialGroup();
    verticalGroup.addComponent(lblHeading)
            .addComponent(scrollPane);

    layout.setHorizontalGroup(horizontalGroup);
    layout.setVerticalGroup(verticalGroup);

    // Fetch and display data from the "Orders" table
    fetchOrdersData();
}
   
	 
	 
	 private void openAddPortfolioPage() {
	        AddPortfolio addPortfolioFrame = new AddPortfolio(tableModel);
	        addPortfolioFrame.setVendorMenu(this);
	        addPortfolioFrame.setVisible(true);
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
 private void fetchOrdersData() {
	        try {
	            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
	            String query = "SELECT * FROM Orders";
	            PreparedStatement preparedStatement = connection.prepareStatement(query);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            while (resultSet.next()) {
	                String orderId = resultSet.getString("order_id");
	                String customerId = resultSet.getString("cus_id");
	                String orderDetails = resultSet.getString("order_details");
	                String status = resultSet.getString("is_active");

	                String[] rowData = {orderId, customerId, orderDetails, status};
	                tableModel.addRow(rowData);
	            }
 
	            resultSet.close();
	            preparedStatement.close();
	            connection.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
 private void fetchDataFromDatabase() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            
            // Modify the query to fetch data only for the logged-in vendor
            String query = "SELECT * FROM Portfolio WHERE ven_id = ?";
            
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, loggedInVendor.getId());

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String pofId = resultSet.getString("pof_id");
                String venId = resultSet.getString("ven_id");
                double pricing = resultSet.getDouble("pricing");
                String description = resultSet.getString("description");
                int capacity = resultSet.getInt("capacity");
                String type = resultSet.getString("Type");

                String[] rowData = {"false", pofId, venId, String.valueOf(pricing), description, String.valueOf(capacity), type};
                tableModel.addRow(rowData);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 public void addDataFromAddPortfolio(String venId, double pricing, String description, int capacity, String type) {
        // Method to receive data from AddPortfolio and update the tableModel
        String newPofId = "POF-" + (tableModel.getRowCount() + 1); // Update this according to your logic
        String[] rowData = {"false", newPofId, venId, String.valueOf(pricing), description, String.valueOf(capacity), type};
        tableModel.addRow(rowData);
        tableModel.fireTableDataChanged();
    }
 public void setSelectedRowIndex(int index) {
        selectedRowIndex = index;
    }
 private void deleteSelectedPortfolio() {
    
	int selectedRowIndex = table.getSelectedRow();
	if (selectedRowIndex != -1) {
        // Get data from the selected row
        String pofId = (String) tableModel.getValueAt(selectedRowIndex, 1);

        // Placeholder for the delete logic
        deletePortfolio(pofId);

        tableModel.removeRow(selectedRowIndex);
        selectedRowIndex = -1; // Reset selected row index after deletion
    }
}
 private void deletePortfolio(String pofId) {
    try {
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
        String query = "DELETE FROM Portfolio WHERE pof_id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);

        preparedStatement.setString(1, pofId);
        preparedStatement.executeUpdate();

        preparedStatement.close();
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}



