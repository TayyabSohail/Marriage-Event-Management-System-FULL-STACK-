package proj;

import java.awt.Color;

public class Theme {
    public static final Color BACKGROUND_COLOR = new Color(243, 151, 130);
    public static final Color PANEL_COLOR = new Color(248, 169, 142);
    public static final Color TEXT_COLOR = new Color(250, 128, 114);
    public static final Color BUTTON_BACKGROUND_COLOR = new Color(255, 255, 255);
    public static final Color BUTTON_TEXT_COLOR = new Color(0, 0, 0);
}
