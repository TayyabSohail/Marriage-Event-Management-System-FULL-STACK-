package proj;


public class Main {

	public static void main(String[] args) {
		
         //Order O = new Order();
		/*
		Cus C = new Cus("CUS-13");
		
		C.selected_portfolio.Pof_name = "Business 1";
		C.selected_portfolio.portfolio_id = "POF-1";
		C.selected_portfolio.capacity = 500;
		C.selected_portfolio.pricing = 500 ; 
		C.selected_portfolio.Type = "Marriage-Hall";
		C.selected_portfolio.description = "SUIIIIII"; 
		C.selected_portfolio.City = "Karachi";
		
		
		Order O = new Order() ; 
		 O.cus_id =  "CUS-13";
		 O.isActive = "PENDING";
		 O.delivery_date = "2023-11-24";
		 O.orderDetails = "newar";
		 O.pof_id = "POF-2";
		 O.req_capacity = 200;
		 
		 C.placeOrder(O);
         
         */
		
		
			
		
		
	 //	'POF-1', 'VEN-1', 'Karachi', '500', 'SUIIIIII', '500', 'Business 1', 'Marriage-Hall'

         //O.check_existing_order("POF-1" , "2023-11-25" );
			
        // boolean capacity_check  = O.check_capacity("POF1")
			    
		  
	} 
};