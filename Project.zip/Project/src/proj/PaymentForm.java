package proj;

import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PaymentForm extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField AmountField;
    private JTextField Payment_Details_textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    PaymentForm frame = new PaymentForm();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public PaymentForm() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 744, 447);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(243, 151, 130));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel PAY_IDLABEL = new JLabel("PAYMENT ID: " + Controller.getInstance().getCustomer().Owd.getPaymentObj().getPayId());
        PAY_IDLABEL.setBounds(249, 87, 168, 26);
        contentPane.add(PAY_IDLABEL);

        JLabel AmountLabel = new JLabel("EnterAmount:");
        AmountLabel.setBounds(32, 214, 114, 14);
        contentPane.add(AmountLabel);

        AmountField = new JTextField();
        AmountField.setBounds(194, 211, 176, 20);
        contentPane.add(AmountField);
        AmountField.setColumns(10);

        JLabel DueAmountLabel = new JLabel("Amount Due: " + Controller.getInstance().getCustomer().Owd.getPaymentObj().getPayAmount());
        DueAmountLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
        DueAmountLabel.setBounds(32, 147, 142, 20);
        contentPane.add(DueAmountLabel);

        JLabel DetailsLabel = new JLabel(" Enter Payment Details: ");
        DetailsLabel.setBounds(28, 254, 142, 14);
        contentPane.add(DetailsLabel);

        Payment_Details_textField = new JTextField();
        Payment_Details_textField.setColumns(10);
        Payment_Details_textField.setBounds(194, 251, 176, 51);
        contentPane.add(Payment_Details_textField);

        JButton Payment_Button = new JButton("PAY");
        Payment_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // business logic
            }
        });
        Payment_Button.setBounds(505, 208, 131, 26);
        contentPane.add(Payment_Button);

        JLabel CUS_BALANCE_LABEL = new JLabel("YOUR CURRENT BALANCE: " + Controller.getInstance().getCustomer().Acc_bal);
        CUS_BALANCE_LABEL.setBounds(457, 90, 210, 20);
        contentPane.add(CUS_BALANCE_LABEL);

        JLabel OrderLabel = new JLabel("Order ID: " + Controller.getInstance().getCustomer().Owd.getPaymentObj().getOrderId());
        OrderLabel.setBounds(32, 93, 138, 14);
        contentPane.add(OrderLabel);

        JLabel Business_Label = new JLabel("Business Name: ");
        Business_Label.setFont(new Font("Times New Roman", Font.BOLD, 18));
        Business_Label.setBounds(32, 26, 142, 26);
        contentPane.add(Business_Label);

        JButton Cancel_button = new JButton("Cancel Transaction");
        Cancel_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // business logic
            }
        });
        Cancel_button.setBounds(505, 263, 151, 26);
        contentPane.add(Cancel_button);

        JLabel Name_label = new JLabel(Controller.getInstance().getCustomer().Owd.fetch_pof_name());
        Name_label.setFont(new Font("Times New Roman", Font.BOLD, 17));
        Name_label.setBounds(183, 26, 159, 26);
        contentPane.add(Name_label);
    }
}
