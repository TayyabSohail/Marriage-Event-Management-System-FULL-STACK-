package proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JFrame;

public class Portfolio extends JFrame {

    String portfolio_id;
    double pricing;
    String description;
    int capacity;
    String Pof_name;
    String Type;
    private String City;
    private String Account_bal;

    Portfolio() {
        portfolio_id = "";
        pricing = 0;
        description = "";
        capacity = 0;
        Pof_name = "";
        Type = "";
    }

    public String getpof_id() {
        return portfolio_id;
    }

    public String getpof_name() {
        return Pof_name;
    }

    public String Account_bal() {
        return Account_bal;
    }

    public double getpricing() {
        return pricing;
    }

    public String getdesc() {
        return description;
    }

    public String gettype() {
        return Type;
    }

    public int getcapacity() {
        return capacity;
    }

    public void setname(String name) {
        this.Pof_name = name;
    }

    public void reset() {
        portfolio_id = "";
        pricing = 0;
        description = "";
        capacity = 0;
        Pof_name = "";
        Type = "";
    }

    public void print_details() {
        System.out.println("Account_bal: " + this.Account_bal);
        System.out.println("Portfolio ID: " + this.portfolio_id);
        System.out.println("Pricing: " + this.pricing);
        System.out.println("Description: " + this.description);
        System.out.println("Capacity: " + this.capacity);
        System.out.println("Business Name: " + this.Pof_name);
        System.out.println("Type: " + this.Type);
    }

    public void addPortfolio(String venId, double pricing, String description, int capacity, String type) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "INSERT INTO Portfolio (Ven_id, Pricing, Description, Capacity, Type) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, venId);
            preparedStatement.setDouble(2, pricing);
            preparedStatement.setString(3, description);
            preparedStatement.setInt(4, capacity);
            preparedStatement.setString(5, type);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updatePortfolio(String venId, double pricing, String description, int capacity, String type) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "UPDATE Portfolio SET Pricing=?, Description=?, Capacity=?, Type=? WHERE Ven_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setDouble(1, pricing);
            preparedStatement.setString(2, description);
            preparedStatement.setInt(3, capacity);
            preparedStatement.setString(4, type);
            preparedStatement.setString(5, venId);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deletePortfolio(String venId) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "DELETE FROM Portfolio WHERE Ven_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, venId);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Vector<Vector<Object>> getAllPortfolioData() {
        Vector<Vector<Object>> data = new Vector<>();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "SELECT * FROM Portfolio";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Vector<Object> rowData = new Vector<>();
                rowData.add("false"); // Placeholder for "Select" column
                rowData.add(resultSet.getString("Ven_id"));
                rowData.add(resultSet.getDouble("Pricing"));
                rowData.add(resultSet.getString("Description"));
                rowData.add(resultSet.getInt("Capacity"));
                rowData.add(resultSet.getString("Type"));
                data.add(rowData);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }
}
