package proj;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



//// our customer is our information expert as it has the data of portfolios , its own data as well as data for orders 
public class Cus extends User {
	
	//// selected portfolio 
	
	/// isme list se portfolio ki value dalke fill karni hai
	Portfolio selected_portfolio = new Portfolio();
	public Order Owd; 
	Cus()
	{
		Owd = new Order();  
	}
	
	//// this function is used to load the object attributes with values from the database table 
	public void fetch_from_db(String id) 
	{
		this.id = id ; 
		
		   String url = "jdbc:mysql://localhost:3306/project";
	        String username = "root";
	        String password = "1234";
	        
		
		// fetching the rest of information from database 
	        
	        String Query = "select * from customer where Id = '" + this.id + "';";
		
		 try (Connection con = DriverManager.getConnection(url, username, password)) {
	        	//System.out.println(city[0]);
	            try (Statement stmt = con.createStatement()) {
	                ResultSet rt = stmt.executeQuery(Query);

	                while (rt.next()) {
	                  //  Portfolio sample = new Portfolio();  // Create a new Portfolio object
	                    this.id = rt.getString("Id");
	                    this.name = rt.getString("Name");
	                    this.Contact = rt.getString("Contact");
	                    this.CNIC = rt.getString("CNIC");
	                    		
	                    //System.out.println(this.name);
	                  this.Acc_bal = rt.getDouble("Account_bal");
	                }
	            }
	        } catch (SQLException g) {
	            g.printStackTrace();
	        }
	}

	
	

	  
	
	
	
	

    public boolean placeOrder(String Ord_Details , int req_capacity  , String delivery_date) {
    	
    	boolean detail_success = false;
    	boolean insert_success = false;
    	Order O = new Order();
    	O.assign_order_id();
    	
    	detail_success = O.EnterDetails(this.selected_portfolio.portfolio_id, this.id , Ord_Details , req_capacity , this.selected_portfolio.Type,
    			delivery_date , this.selected_portfolio.capacity , this.selected_portfolio.pricing);
    	
    	if (detail_success)
    	{
    		insert_success = O.insert_inDB();
    	}
    	
    	if (detail_success && insert_success)
    	{
    		return true;
    	}
    	else 
    	{
    		return false;
    	}
    	
    	
        
    }
    
    
    ////USE CASE 1 
    public ArrayList<String[]>  Search_Vedor(boolean[] city_flag  , boolean[] price_flag  , boolean [] cap_flag , String Type , String pof_name)
    {
    	 
    	ArrayList<String[]> fetched_portfolios = new ArrayList<>();
    	  
    	String [] cityQueries = {"''", "''", "''" , "''"};
    	   String [] pricingQueries = {"(pricing>=0 AND pricing <=1400)",
    			   "(pricing>=1401 AND pricing <=1800)",
    			   "(pricing>=1801 AND pricing <2500) " , 
    			   "(pricing>=2500)"};
    	   String [] capacityQueries = {"(capacity>=0 AND capacity <=100)",
    			   "(capacity>=101 AND capacity <=300)",
    			   "(capacity>=301 AND capacity <600) " , 
    			   "(capacity>=600)"};
    	        
    	        
    	        	StringBuilder querybuild_cap = new StringBuilder();
    	        	
    	        	querybuild_cap.append("select * from portfolio where ");
    	        	
    	        	 
    	        	 
    	        	if(cap_flag[0]) {
    	        		querybuild_cap.append(capacityQueries[0]);
    	        		querybuild_cap.append(" OR ");
    	        		
    	        	}
    	        	if (cap_flag[1])
    	        	{
    	        		querybuild_cap.append(capacityQueries[1]);
    	        		querybuild_cap.append(" OR ");
    	        	}
    	        	if (cap_flag[2])
    	        	{
    	        		querybuild_cap.append(capacityQueries[2]);
    	        		querybuild_cap.append(" OR ");
    	        	}
    	        	if (cap_flag[3])
    	        	{
    	        		querybuild_cap.append(capacityQueries[3]);
    	        		querybuild_cap.append(" OR ");
    	        	}
    			
    	        //	querybuild_cap.append(";");
    	        	
    	        	
    	        	 int lastOr_start_cap = querybuild_cap.length() - 4;
    	        	 int lastOr_end_cap = querybuild_cap.length() ;
    	        	
    	        	  querybuild_cap.delete(lastOr_start_cap, lastOr_end_cap);
    	        	  
    	        	//  System.out.println("Modified StringBuilder: " + querybuild_cap);
    	        
    	        	  
    	        	  
    	        		StringBuilder querybuild_pricing = new StringBuilder();
    	            	
    	            	querybuild_pricing.append("select * from portfolio where ");
    	            	
    	            	 
    	            	 
    	            	if(price_flag[0]) {
    	            		querybuild_pricing.append(pricingQueries[0]);
    	            		querybuild_pricing.append(" OR ");
    	            		
    	            		//System.out.println(querybuild_pricing);
    	            		
    	            	}
    	            	if (price_flag[1])
    	            	{
    	            		querybuild_pricing.append(pricingQueries[1]);
    	            		querybuild_pricing.append(" OR ");
    	            		
    	            		//System.out.println(querybuild_pricing);
    	            	}
    	            	if (price_flag[2])
    	            	{
    	            		querybuild_pricing.append(pricingQueries[2]);
    	            		querybuild_pricing.append(" OR ");
    	            		//System.out.println(querybuild_pricing);
    	            	}
    	            	if (price_flag[3])
    	            	{
    	            		querybuild_pricing.append(pricingQueries[3]);
    	            		querybuild_pricing.append(" OR ");
    	            	//	System.out.println(querybuild_pricing);
    	            	}
    	    		
    	            //	querybuild_pricing.append(";");
    	            	
    	            	
    	            	 int lastOr_start_pri = querybuild_pricing.length() - 4;
    	            	 int lastOr_end_pri = querybuild_pricing.length() ;
    	            	
    	            	  querybuild_pricing.delete(lastOr_start_pri, lastOr_end_pri);
    	            	  
    	            	 // System.out.println("Modified StringBuilder: " + querybuild_pricing);
    	            
    	        	  
    	        	  
    	        	
    	        if (city_flag[0])
    			{
    				//System.out.println("Karachi");
    				cityQueries[0]= "'Karachi'";
    			}
    			if (city_flag[1])
    			{
    				//System.out.println("Lahore");
    				cityQueries[1]= "'Lahore'";
    			}
    			if (city_flag[2])
    			{
    				//System.out.println("Islamabad");
    				cityQueries[2]= "'Islamabad'";
    			}
    			if (city_flag[3])
    			{
    				//System.out.println("Rawalpindi");
    				cityQueries[3]= "'Rawalpindi'";
    			}
    				
    			

    	        String url = "jdbc:mysql://localhost:3306/project";
    	        String username = "root";
    	        String password = "1234";
    	        		String combined_query = "";
    	        		String Query = "select * from Portfolio where Type = '" + Type + "'";
    	        		String Query1 = "select * from Portfolio where business_name = '" + pof_name + "'";
    	        		String Query2 = "SELECT * FROM Portfolio WHERE city IN (" +  cityQueries[0]  + "," + cityQueries[1] + "," + 
    	        		cityQueries[2] + "," + cityQueries[3] + ")";
    	        		String Query3 = querybuild_cap.toString();
    	        		String Query4 = querybuild_pricing.toString(); 
    	        		System.out.println(Query);
    	        		
    	        		combined_query = Query + " UNION " +Query1;
    	        		
    	        		
    	        		if (city_flag[0] || city_flag[1] || city_flag[2] || city_flag[2])
    	        		{
    	        			combined_query = Query + " UNION " +Query1 + " UNION " + Query2;
    	        		}
    	        		
    	        		if (cap_flag[0] || cap_flag[1] || cap_flag[2] || cap_flag[3])   // checks for capacity
    	        		{
    	        			combined_query = Query + " UNION " +Query1 + " UNION " + Query2 + " UNION " + Query3;
    	        		}
    	        		
    	        		if (price_flag[0] || price_flag[1] || price_flag[2] || price_flag[3])
    	        		{
    	        			combined_query = Query + " UNION " + Query1 + " UNION " + Query2 + " UNION " + Query3 + " UNION " + Query4;
    	        		}
    	        		
    	        		combined_query += ";";
    	        		
    	        try (Connection con = DriverManager.getConnection(url, username, password)) {
    	        	//System.out.println(city[0]);
    	            try (Statement stmt = con.createStatement()) {
    	                ResultSet rt = stmt.executeQuery(combined_query);
    	                
    	                while (rt.next()) {
    	                	Portfolio sample = new Portfolio();  // Create a new Portfolio object
    	                	sample.portfolio_id = rt.getString("pof_id");
    	                    sample.Pof_name = rt.getString("business_name");
    	                    sample.pricing = rt.getDouble("pricing");
    	                    sample.description = rt.getString("description");
    	                    sample.capacity = rt.getInt("capacity");
    	                    sample.Type = rt.getString("Type");
    	                   // fetchedPortfolios.add(sample);

    	                    String[] rowData = {sample.portfolio_id,sample.Pof_name, String.valueOf(sample.pricing),
    	                            sample.description, String.valueOf(sample.capacity), sample.Type};
    	                 fetched_portfolios.add(rowData);
    	                 
    	                 sample = null; 
    	                    
    	                   // System.out.println(sample.getpof_name());
    	                }
    	            }
    	        } catch (SQLException g) {
    	            g.printStackTrace();
    	        }
    	        
    	        return fetched_portfolios;
    	       
    	    }
    
    public ArrayList<String[]>  ViewOrder()
	{
		
			Order O  = new Order();
			ArrayList<String[]> Fetched_Orders = new ArrayList<>();
			 String url = "jdbc:mysql://localhost:3306/project";
    	        String username = "root";
    	        String password = "1234";
    	        
    	      //  System.out.println(this.id);
    	        
    	        String Query = "select * from orders where cus_id = '" + this.id + "' ;";
    	        		
    	        try (Connection con = DriverManager.getConnection(url, username, password)) {
    	        	//System.out.println(city[0]);
    	            try (Statement stmt = con.createStatement()) {
    	                ResultSet rt = stmt.executeQuery(Query);
    	                
    	             //   pof_id, order_id, delivery_date, cus_id, order_details, is_active, required_cap, orderbill, Type
    	                
    	                while (rt.next()) {
    	                	
    	                    O.order_id = rt.getString("order_id");
    	                	O.cus_id = rt.getString("cus_id");
    	                    O.delivery_date = rt.getString("delivery_date");
    	                    O.isActive = rt.getString("is_active");
    	                    O.order_bill = rt.getDouble("orderbill");
    	                    O.orderDetails = rt.getString("order_details");
    	                    O.pof_id = rt.getString("pof_id");
    	                    O.req_capacity = rt.getInt("required_cap");
    	                    O.type = rt.getString("Type");
    	                   // fetchedPortfolios.add(sample);

    	                    String[] rowData = {O.order_id,O.pof_id, O.delivery_date,
    	                             O.orderDetails, O.isActive , String.valueOf(O.req_capacity) , String.valueOf (O.order_bill) , O.type};
    	                    	Fetched_Orders.add(rowData);
    	                 
    	                // sample = null; 
    	                    	
    	                    	
    	                    	///a function to nullyfy attributtes
    	                    	O.emptyOrder();
    	                    
    	                   // System.out.println(sample.getpof_name());
    	                }
    	            }
    	        } catch (SQLException g) {
    	            g.printStackTrace();
    	        }

						return Fetched_Orders;
	}
    public String getCustomerId() {
        String customerId = null;

        String url = "jdbc:mysql://localhost:3306/project";
        String username = "root";
        String password = "1234";

        String query = "SELECT Id FROM customer WHERE Name = '" + this.name + "';";
        
        try (Connection con = DriverManager.getConnection(url, username, password)) {
            try (Statement stmt = con.createStatement()) {
                ResultSet rs = stmt.executeQuery(query);

                if (rs.next()) {
                    customerId = rs.getString("Id");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerId;
    }

    
    
}
