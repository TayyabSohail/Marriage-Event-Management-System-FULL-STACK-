package proj;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Login extends JFrame {

    private JTextField username;
    private JPasswordField passwordField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Login frame = new Login();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }  
        });
    }
 
    public Login() {
        setType(Type.UTILITY);
        setTitle("LOGIN FORM");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 424);
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(Theme.BACKGROUND_COLOR);
        panel.setBounds(10, 11, 664, 78);
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("LOGIN");
        lblNewLabel.setFont(new Font("Trebuchet MS", Font.PLAIN, 30));
        lblNewLabel.setForeground(Color.BLACK); // Set the foreground color to black
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(150, 11, 324, 54);
        panel.add(lblNewLabel);

        username = new JTextField();
        username.setBounds(353, 140, 223, 26);
        getContentPane().add(username);
        username.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("USERNAME");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setBounds(173, 137, 152, 33);
        getContentPane().add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("PASSWORD");
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2.setBounds(210, 205, 77, 26);
        getContentPane().add(lblNewLabel_2);

        passwordField = new JPasswordField();
        passwordField.setBounds(353, 205, 223, 26);
        getContentPane().add(passwordField);

        JButton btnNewButton = new JButton("LOGIN");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String u = username.getText();
                char[] p = passwordField.getPassword();
                String pass = new String(p);

                // calling the controller class here to implement the business logic layer
                boolean flag = Controller.getInstance().getregister().checkLogin(u, pass);

                if (flag) {
                    // Login Successful
                    JOptionPane.showMessageDialog(null, "Login Successful");

                    // Navigate from customer to vendor page
                    if (u.charAt(0) == 'C') {
                        Controller.getInstance().getCustomer().fetch_from_db(u);
                        Customer customerFrame = new Customer();
                        customerFrame.setVisible(true);
                        dispose();
                    } else if (u.charAt(0) == 'V') {
                        Controller.getInstance().getVendor().fetch_from_db(u);
                        VendorMenu vendorFrame = new VendorMenu(Controller.getInstance().getVendor());
                        vendorFrame.setVisible(true);
                        dispose();
                        // Do your vendor work here
                    }
                } else {
                    // Login Failed
                    JOptionPane.showMessageDialog(null, "Username or Password Incorrect", "Login Failed",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnNewButton.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
        btnNewButton.setBackground(Theme.BUTTON_BACKGROUND_COLOR);
        btnNewButton.setForeground(Theme.BUTTON_TEXT_COLOR);
        btnNewButton.setBounds(373, 293, 119, 33);
        getContentPane().add(btnNewButton);
    }
}
