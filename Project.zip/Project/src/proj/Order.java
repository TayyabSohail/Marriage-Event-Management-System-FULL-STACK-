// Order.java
package proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


//setting order_id  --done
//applying capacity check on orders  -- done
//applying existing order checks on orders  -- done
// calculating total bill using a union query with portfolio to fetch per person budget from portfolio object
// customer ID and pof ID are to be fetched from the search vendor file
//remove order description from database
public class Order {
   public String pof_id;
    public String order_id;  // work on order id is also to be done
    public String cus_id;
    public String orderDetails;
    public String isActive;
    //private String description;
    public int req_capacity;
    //private String businessName;
    public String type;
    public String delivery_date;
    public double order_bill ; 
    
    // a composition of payment object to use 
    	 private Payment Ord_payment ; 

    public Order() {
        
    	

         orderDetails = ""; 
         isActive = "PENDING"; 
        // description = ""; 
         req_capacity = 0 ; 
         type = ""; 
         delivery_date = ""; 
         order_bill = 0.0 ;
         
         
         
         //assigning a unqiue order ID from this too 
         Ord_payment = new Payment();
         
         
        		 
         
    }
    
    public Payment getPaymentObj()
    {
    	return Ord_payment ; 
    }
  
    public boolean EnterDetails(String pid ,  String c_id , String orderDetails , int req_capacity , String type ,String delivery_date , int portfolio_capacity , double pricing )
    {
    	
    	
    
    	
    	boolean success_flag = false ; 

    
       
        	
        boolean existing_order_flag = this.check_existing_order(pid , delivery_date) ; 
        
       // System.out.println(pid);
        boolean capacity_flag = this.capacity_check( req_capacity ,portfolio_capacity);
    
            
       
            
            
              if (existing_order_flag && capacity_flag && delivery_date !="")
                {
            	
            			success_flag = true ; 
		            	this.orderDetails = orderDetails ; 
		            	this.req_capacity = req_capacity ; 
		            	this.type = type ; 
		            	this.delivery_date = delivery_date;
		            	this.cus_id = c_id;
		            	this.pof_id = pid;
		            	this.order_bill = req_capacity * pricing ;
		            	
		            	System.out.println("Displaying of order bill is missing , also check if int is sufficient as a data type " + this.order_bill);
            	}
              	else 
              	{	
              	System.out.println("Flags gone false");
              	
              	 success_flag = false; 
              	}
            
            return success_flag;
        
    }
    
    public void assign_order_id()
    {
     	
        String url = "jdbc:mysql://localhost:3306/project";
        String username = "root";
        String password = "1234";
        
        
        String separator = "";
        int unique_num = 0;

        try (Connection con = DriverManager.getConnection(url, username, password)) {
       	 	this.order_id = "ORD-1";
       	 	
                try (Statement stmt = con.createStatement()) {
                    ResultSet rt = stmt.executeQuery(
                            "SELECT order_id FROM Orders  ORDER BY order_id DESC LIMIT 1;");

                    while (rt.next()) {
                        order_id = rt.getString("order_id");

                        for (int i = 4; i < order_id.length(); i++) {
                            separator += order_id.charAt(i);
                        }

                        unique_num = Integer.parseInt(separator);
                        unique_num++;
                        this.order_id = "ORD-" + String.valueOf(unique_num);
                       // System.out.println(order_id);
                    }
                }
       
   }catch (SQLException e) {
       e.printStackTrace();
   }
        
        
    }

   
    
    public boolean check_existing_order(String pofid , String Delivery_D)
    {
    		String url = "jdbc:mysql://localhost:3306/project";
    		String username = "root";
    		String password = "1234";
    		
    		boolean flag = false;

    		String Query = "select * from orders where pof_id  =  '" + pofid + "'" + " AND " + "delivery_date = '" + Delivery_D + "';" ;
    			
    	 try (Connection con = DriverManager.getConnection(url, username, password)) {
         	
    		 		
    		  try (Statement stmt = con.createStatement()) {
                  ResultSet rt = stmt.executeQuery(Query);

                  if (rt.next()) {
                	  		//	System.out.println("An exixting order has been found");
                	  			flag = false; 
                  }
                  else 
                  {
                	  //System.out.println("No existing order is found");
                	  flag = true;
                  }
              }
             
             
             
         } catch (SQLException e) {
             e.printStackTrace();  // Log or handle the exception appropriately
         }
    	 
    	 
    	
    	 
    	    
    	
    	 return flag;
    }
    
    
    
    
    public boolean capacity_check( int req_cap ,int pof_cap)
	 {
		 boolean flag = false; 
		 
		 if (pof_cap >= req_cap)
		 {
			 flag = true; 
		 }
		 else 
		 {
			 flag = false;
		 }
		 
		 return flag;
	 }
    
    
    
    public boolean insert_inDB() 
    {
    		boolean flag = false;
        String url = "jdbc:mysql://localhost:3306/project";
        String username = "root";
        String password = "1234";

        try (Connection con = DriverManager.getConnection(url, username, password)) {
        	
       
        //boolean capacity_check  = check_capacity() ;   // this is to check whether the entered exceeds avaliable capacity
            String sql = "INSERT INTO Orders (pof_id, order_id, delivery_date ,cus_id,order_details, is_active, required_cap, Type, orderbill) " +
                         "VALUES (?,?, ?, ?, ?, ?, ?, ?, ?)";
            
            
            
            	 
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            	pstmt.setString(1, this.pof_id);  
            	pstmt.setString(2, this.order_id);
                pstmt.setString(3, this.delivery_date);     /// input from user
                pstmt.setString(4, this.cus_id);   // customer id
                pstmt.setString(5, this.orderDetails);      /// input from user
                pstmt.setString(6, this.isActive);      ///work on how the order is completed think further
             
                pstmt.setInt(7,  this.req_capacity);        //input from user
                
                pstmt.setString(8, this.type);
                pstmt.setDouble(9, this.order_bill);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Order placed successfully!");
                    flag = true ; 
                    
                } else {
                    System.out.println("Failed to place order in the table.");
                    flag = false; 
                    
                }
            }
            
            
            
        } catch (SQLException e) {
            e.printStackTrace();  // Log or handle the exception appropriately
        }
        
        
        return flag ; 
    }
    

	 //getters for orders ; 
	 
	 // Getter methods
    public String getPof_id() {
	        return pof_id;
	    }

	    public String getOrder_id() {
	        return order_id;
	    }

	    public String getCus_id() {
	        return cus_id;
	    }

	    public String getOrderDetails() {
	        return orderDetails;
	    }

	    public String getIsActive() {
	        return isActive;
	    }

	   // public String getDescription() {
	     //   return description;
	   // }

	    public int getReq_capacity() {
	        return req_capacity;
	    }

	    // Getter method for businessName if you uncomment it
	    // public String getBusinessName() {
	    //     return businessName;
	    // }

	    public String getType() {
	        return type;
	    }

	    public String getDelivery_date() {
	        return delivery_date;
	    }

	    public double getOrder_bill() {
	        return order_bill;
	    }
	 
	    
	    	//setters start here
	    
	
    
	    public void setOrderBill(double bill) {
	        this.order_bill  = bill;
	    }
	    
	    public void setPofID(String PofID) {
	        this.pof_id = PofID;
	    }

	    
	    
	   
	    public void setOrder_id(String order_id) {
	        this.order_id = order_id;
	    }

	    public void setCus_id(String cus_id) {
	        this.cus_id = cus_id;
	    }

	    public void setOrderDetails(String orderDetails) {
	        this.orderDetails = orderDetails;
	    }

	    public void setIsActive(String isActive) {
	        this.isActive = isActive;
	    }

	    

	    public void setReq_capacity(int req_capacity) {
	        this.req_capacity = req_capacity;
	    }


	    public void setType(String type) {
	        this.type = type;
	    }

	    public void setDelivery_date(String delivery_date) {
	        this.delivery_date = delivery_date;
	    }

	    
	    public  boolean isValidDate(String dateStr, String format) {
	        try {
	            SimpleDateFormat sdf = new SimpleDateFormat(format);
	            sdf.setLenient(false); // Strict parsing
	            Date date = sdf.parse(dateStr);
	            return true; // If parsing succeeds, the date is valid
	        } catch (ParseException e) {
	            return false; // Parsing failed, so the date is invalid
	        }
	    }
	    
	    
	    
	    	
	    	
	    	public String fetch_pof_name(String pofid)
	    	
	    	{
	    					String url = "jdbc:mysql://localhost:3306/project";
	    					String username = "root";
	    					String password = "1234";
	    					
	    					String name = "";
	    					
	    					//boolean flag = false;
	    			
	    					String Query = "select business_name from portfolio where pof_id  =  '" + pofid + "';" ;
	    						
	    				 try (Connection con = DriverManager.getConnection(url, username, password)) {
	    			     	
	    					 		
	    					  try (Statement stmt = con.createStatement()) {
	    			              ResultSet rt = stmt.executeQuery(Query);
	    			
	    			              if (rt.next()) {
	    			            	  		//	System.out.println("An exixting order has been found");
	    			            	  			//flag = false;
	    			            	   name = rt.getString("business_name");
	    			              }
	    			              
	    			          }
	    			         
	    			         
	    			         
	    			     } catch (SQLException e) {
	    			         e.printStackTrace();  // Log or handle the exception appropriately
	    			     }
	    				 
	    				 
	    				 return name;
	    	}
	    	
	    	

	    	public void emptyOrder()
	    	{
	    		  pof_id = "";
	    		    order_id  = "";  // work on order id is also to be done
	    		     cus_id ="";
	    		    orderDetails = "";
	    		     isActive =  "";
	    		    //private String description;
	    		     req_capacity =0;
	    		    //private String businessName;
	    		     type = "";
	    		     delivery_date ="";
	    		     order_bill = 0.0 ; 
	    		     
	    		     Ord_payment.clearPaymentobj();
	    	}
	    	
	    	

	    	
	    	
	    	
	    	
	    	public String fetch_pof_name()
	    	
	    	{
	    					String url = "jdbc:mysql://localhost:3306/project";
	    					String username = "root";
	    					String password = "1234";
	    					
	    					String name = "";
	    					
	    					//boolean flag = false;
	    			
	    					String Query = "select business_name from portfolio where pof_id  =  '" + this.pof_id + "';" ;
	    						
	    				 try (Connection con = DriverManager.getConnection(url, username, password)) {
	    			     	
	    					 		
	    					  try (Statement stmt = con.createStatement()) {
	    			              ResultSet rt = stmt.executeQuery(Query);
	    			
	    			              if (rt.next()) {
	    			            	  		//	System.out.println("An exixting order has been found");
	    			            	  			//flag = false;
	    			            	   name = rt.getString("business_name");
	    			              }
	    			              
	    			          }
	    			         
	    			         
	    			         
	    			     } catch (SQLException e) {
	    			         e.printStackTrace();  // Log or handle the exception appropriately
	    			     }
	    				 
	    				 
	    				 return name;
	    	}
	    	
	    	
	    	
	    	public void updateStatus()
	    	{
	    		
	    		System.out.println(this.order_id);
	    		
	    		try {
	               

	                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
	                String query = "UPDATE orders SET is_active=? WHERE order_id=?";
	                PreparedStatement preparedStatement = connection.prepareStatement(query);

	                preparedStatement.setString(1, this.isActive);
	                preparedStatement.setString(2, this.order_id);

	                preparedStatement.executeUpdate();

	               
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	    				
	    	}

			public void emptyFeedback() {
				
				order_id  = "";  // work on order id is also to be done
   		     	cus_id ="";
   		  //clearFeedbackobj();
			}
	    	
	    
}