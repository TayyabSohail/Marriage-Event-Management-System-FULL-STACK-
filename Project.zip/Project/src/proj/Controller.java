package proj;



///singleton factor pattern is used for controller class 
public class Controller {
			
	
	
	private static Controller unique_controller  =  null;
	
	private Cus Customer_loggedin  = null ; 
	private Register register_obj = null ; 
	private Vendor Vendor_loggedin  = null ;   
	 
	 // make vendor object here as well 
	 
	 
	
	private Controller()
	{
		Customer_loggedin = new Cus();
		register_obj = new Register();
		Vendor_loggedin = new Vendor(); 
	}
	
	public static Controller getInstance(){

		if(unique_controller==null)

		unique_controller = new Controller();

		return unique_controller;

		}
	
	
	public Cus getCustomer() {
		
			return Customer_loggedin;
	}
	
	public Vendor getVendor()
	{
		return Vendor_loggedin;
	}

	public  Register getregister() {
		
			return register_obj;
	}
	
		
		
	
	

	
}
