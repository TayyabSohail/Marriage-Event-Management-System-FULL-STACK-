package proj;
import java.sql.*;

public class Register {

    private String Username;
    private String Password;
    
    
    /////testing variables 
    
    String testor;
    ////

    Register() {
        Username = "";
        Password = "122";
        
        testor = "";
    }

    public void register(String User_Type , String Name , String CNIC , String Contact ) {

       

        int a = Integer.parseInt(Password);
        a++;
        Password = String.valueOf(a);
        a = 0;

        String separator = "";
        int unique_num = 0;

        String url = "jdbc:mysql://localhost:3306/project";
        String username = "root";
        String password = "1234";

        try (Connection con = DriverManager.getConnection(url, username, password)) {

            if (User_Type == "VENDOR") {
                Username = "VEN-1";

                try (Statement stmt = con.createStatement()) {
                    ResultSet rt = stmt.executeQuery(
                            "SELECT User_Id FROM registration WHERE User_ID LIKE 'VEN%' ORDER BY User_Id DESC LIMIT 1;");

                    while (rt.next()) {
                        Username = rt.getString("User_ID");

                        for (int i = 4; i < Username.length(); i++) {
                            separator += Username.charAt(i);
                        }

                        unique_num = Integer.parseInt(separator);
                        unique_num++;
                        Username = "VEN-" + String.valueOf(unique_num);
                    }
                }
                
                

                String sqlVendor = "INSERT INTO Vendor(ID, Name, CNIC, Contact) VALUES (?, ?, ?, ?)";
                try (PreparedStatement preparedStatementVendor = con.prepareStatement(sqlVendor)) {
                    preparedStatementVendor.setString(1, Username);
                    preparedStatementVendor.setString(2, Name);
                    preparedStatementVendor.setString(3, CNIC);
                    preparedStatementVendor.setString(4, Contact);

                    int rowsInserted = preparedStatementVendor.executeUpdate();

                    if (rowsInserted > 0) {
                        System.out.println("Vendor data inserted successfully!");
                    }
                }

            } else if (User_Type == "CUSTOMER") {
                Username = "CUS-1";

                try (Statement stmt = con.createStatement()) {
                    ResultSet rt = stmt.executeQuery(
                            "SELECT User_Id FROM registration WHERE User_ID LIKE 'CUS%' ORDER BY User_Id DESC LIMIT 1;");

                    while (rt.next()) {
                        Username = rt.getString("User_ID");

                        for (int i = 4; i < Username.length(); i++) {
                            separator += Username.charAt(i);
                        }

                        unique_num = Integer.parseInt(separator);
                        unique_num++;
                        Username = "CUS-" + String.valueOf(unique_num);
                    }
                }

                String sqlCustomer = "INSERT INTO Customer(ID, Name, CNIC, Contact) VALUES (?, ?, ?, ?)";
                try (PreparedStatement preparedStatementCustomer = con.prepareStatement(sqlCustomer)) {
                    preparedStatementCustomer.setString(1, Username);
                    preparedStatementCustomer.setString(2, Name);
                    preparedStatementCustomer.setString(3, CNIC);
                    preparedStatementCustomer.setString(4, Contact);

                    int rowsInserted = preparedStatementCustomer.executeUpdate();

                    if (rowsInserted > 0) {
                        System.out.println("Customer data inserted successfully!");
                    }
                }

            }

            String sqlRegistration = "INSERT INTO REGISTRATION(User_Id, password) VALUES (?, ?)";
            try (PreparedStatement preparedStatementRegistration = con.prepareStatement(sqlRegistration)) {
                preparedStatementRegistration.setString(1, Username);
                preparedStatementRegistration.setString(2, Password);

                int rowsInserted = preparedStatementRegistration.executeUpdate();

                if (rowsInserted > 0) {
                    System.out.println("Registration data inserted successfully!");
                }
            }
            
         } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
    
    
    
    public boolean checkLogin(String username, String password) {
    	boolean flag = false;
        String url = "jdbc:mysql://localhost:3306/project";
        String username1 = "root";
        String password1 = "1234";

        try (Connection con = DriverManager.getConnection(url, username1, password1)) {
            try (Statement stmt = con.createStatement()) {
                ResultSet rt = stmt.executeQuery(
                        "SELECT * FROM Registration WHERE User_Id = '" + username + "' AND password = '" + password + "';");

                if (rt.next()) {
                    flag = true;
                    	
                } else {
                    System.out.println("User not found");
                    flag = false;
                    	
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        
        
        return flag ; 
    }

};
