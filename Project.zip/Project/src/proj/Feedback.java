// Feedback.java
package proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Feedback {
    private String customerId;
    private String orderId;

    public Feedback(String customerId, String orderId) {
        this.customerId = customerId;
        this.orderId = orderId;
    }

    // Getter methods
    public String getCustomerId() {
        return customerId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void saveFeedbackToDatabase(String comment, int stars) {
        String url = "jdbc:mysql://localhost:3306/project";
        String username = "root";
        String password = "1234";

        try (Connection con = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO Feedback (order_id, customer_id, comment, stars) VALUES (?, ?, ?, ?)";

            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, orderId);
                pstmt.setString(2, customerId);
                pstmt.setString(3, comment);
                pstmt.setInt(4, stars);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Feedback saved successfully!");
                } else {
                    System.out.println("Failed to save feedback.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
