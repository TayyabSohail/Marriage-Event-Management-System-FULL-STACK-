package proj;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ArrayList;
public class SearchVendor extends JPanel {

    private JTextField searchBar;
    private JButton searchButton;
    private JTable portfolioTable;
    private DefaultTableModel tableModel;
   //   private ArrayList<Portfolio> fetchedPortfolios;  // Declare here
    private JTextField txtSubAreaEg;
    
   
    JCheckBox chckbxNewCheckBox;
    JCheckBox chckbxNewCheckBox_1;
    JCheckBox chckbxNewCheckBox_2;
    JCheckBox chckbxNewCheckBox_3;
    JCheckBox chckbxNewCheckBox_4;
    JCheckBox chckbxNewCheckBox_5;
    JCheckBox chckbxNewCheckBox_6;
    JCheckBox chckbxNewCheckBox_7;
    JCheckBox chckbxNewCheckBox_8;
    JCheckBox chckbxNewCheckBox_9;
    JCheckBox chckbxNewCheckBox_10;
    JCheckBox chckbxNewCheckBox_11;
    JComboBox comboBox;
    JLabel Customer_label;
    		JLabel Name;
     JLabel lblNewLabel;
     JLabel lblCnic;
     JLabel CNIC_label;
     JLabel lblContactDetails;
     JLabel Contact_label;
    
    
    
    /// an object for the customer
    
    public SearchVendor() {
    	
    	
    	
        setLayout(null);

        searchBar = new JTextField();
        searchBar.setBounds(401, 101, 227, 22);
        add(searchBar);
        searchBar.setColumns(10);

        searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
        	
            public void actionPerformed(ActionEvent e) {
            	
            	 tableModel.setRowCount(0);
            	 boolean[] city_flags = new boolean[4];
            	 boolean[] cap_flags = new boolean[4];
            	 boolean[]  price = new boolean[4];
            	    
            	  
            	    city_flags[0] = chckbxNewCheckBox.isSelected();
        	        city_flags[1] = chckbxNewCheckBox_1.isSelected();
        	        city_flags[2] = chckbxNewCheckBox_2.isSelected();
        	        city_flags[3] = chckbxNewCheckBox_3.isSelected();
        	        
        	        //c1 c2 c3 and c4  are flags for capacity
        	        cap_flags[0] = chckbxNewCheckBox_4.isSelected();
        	        cap_flags[1] = chckbxNewCheckBox_5.isSelected();
        	        cap_flags[2] = chckbxNewCheckBox_6.isSelected();
        	        cap_flags[3] = chckbxNewCheckBox_7.isSelected();
        	        
        	       // p1 p2 p3 and p4 are flags for pricing filters
        	        price[0] = chckbxNewCheckBox_8.isSelected();
        	        price[1] = chckbxNewCheckBox_9.isSelected();
        	        price[2] = chckbxNewCheckBox_10.isSelected();
        	        price[3] = chckbxNewCheckBox_11.isSelected();
        	        
        	        String Type = (String) comboBox.getSelectedItem();
        	        String name = searchBar.getText();
        	        
        	        
        	        //Business logic layer connected here
        	        
        	        ArrayList<String[]> rows =  Controller.getInstance().getCustomer().Search_Vedor(city_flags , cap_flags , price , Type , name);
        	        
        	        
        	        for (String element[] : rows) {
        	            		tableModel.addRow(element);
        	        }
               
            }
        });
        searchButton.setBounds(310, 427, 80, 30);
        add(searchButton);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("PortFolio ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Pricing");
        tableModel.addColumn("Description");
        tableModel.addColumn("Capacity");
        tableModel.addColumn("Type");
        		
        
        String[] choices = { "","Marriage-Hall", "Catrers"};
		 comboBox = new JComboBox(choices);
		comboBox.setBounds(24, 108, 177, 22);
		add(comboBox);
		
		JLabel CityLabel = new JLabel("City");
		 
		CityLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		CityLabel.setBounds(24, 160, 61, 18);
		add(CityLabel);
		
		
		 chckbxNewCheckBox = new JCheckBox("Karachi");
		chckbxNewCheckBox.setBounds(24, 185, 97, 23);
		add(chckbxNewCheckBox);
		
		 chckbxNewCheckBox_1 = new JCheckBox("Lahore");
		chckbxNewCheckBox_1.setBounds(123, 185, 97, 23);
		add(chckbxNewCheckBox_1);
		// Lahore_select = chckbxNewCheckBox_1.isSelected();
		
		chckbxNewCheckBox_2 = new JCheckBox("Islamabad");
		chckbxNewCheckBox_2.setBounds(24, 211, 97, 23);
		add(chckbxNewCheckBox_2);
		//Islamabad_select = chckbxNewCheckBox_2.isSelected();
		
		 chckbxNewCheckBox_3 = new JCheckBox("Rawalpindi");
		chckbxNewCheckBox_3.setBounds(123, 211, 97, 23);
		add(chckbxNewCheckBox_3);
		 //Rawalpindi_select = chckbxNewCheckBox_3.isSelected();
			
		
        portfolioTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(portfolioTable);
        scrollPane.setBounds(247, 134, 550, 250);
        add(scrollPane);
        
        
        
    //    txtSubAreaEg = new JTextField();
      //  txtSubAreaEg.putClientProperty("JTextField.placeholderText", "e.g. G-10 Markaz");
        //txtSubAreaEg.setColumns(10);
        //txtSubAreaEg.setBounds(24, 216, 150, 25);
        //add(txtSubAreaEg);
        //txtSubAreaEg.setVisible(true);
        
       // JLabel Location_label = new JLabel("Location");
       // Location_label.setFont(new Font("Tahoma", Font.BOLD, 13));
        //Location_label.setBounds(24, 187, 61, 18);
        //add(Location_label);
        
        
        
        JLabel Capacity_label = new JLabel("Capactiy");
        Capacity_label.setFont(new Font("Tahoma", Font.BOLD, 13));
        Capacity_label.setBounds(24, 252, 61, 18);
        add(Capacity_label);
        
        
        //check boxes for capacity start here 
         chckbxNewCheckBox_4 = new JCheckBox("0-100");
        chckbxNewCheckBox_4.setBounds(24, 277, 97, 23);
        add(chckbxNewCheckBox_4);
        
         chckbxNewCheckBox_5 = new JCheckBox("101-300");
        chckbxNewCheckBox_5.setBounds(123, 277, 97, 23);
        add(chckbxNewCheckBox_5);
        
         chckbxNewCheckBox_6 = new JCheckBox("301-599");
        chckbxNewCheckBox_6.setBounds(24, 317, 97, 23);
        add(chckbxNewCheckBox_6);
        
         chckbxNewCheckBox_7 = new JCheckBox("600+");
        chckbxNewCheckBox_7.setBounds(123, 317, 97, 23);
        add(chckbxNewCheckBox_7);
        
        JLabel Pricing_label = new JLabel("Budget (Per Person)");
        Pricing_label.setFont(new Font("Tahoma", Font.BOLD, 13));
        Pricing_label.setBounds(24, 358, 133, 18);
        add(Pricing_label);
        
        chckbxNewCheckBox_8 = new JCheckBox("0-1400");
        chckbxNewCheckBox_8.setBounds(24, 394, 97, 23);
        add(chckbxNewCheckBox_8);
        
        chckbxNewCheckBox_9 = new JCheckBox("1401-1800");
        chckbxNewCheckBox_9.setBounds(123, 394, 97, 23);
        add(chckbxNewCheckBox_9);
        
         chckbxNewCheckBox_10 = new JCheckBox("1800-2500");
        chckbxNewCheckBox_10.setBounds(24, 431, 97, 23);
        add(chckbxNewCheckBox_10);
        
        chckbxNewCheckBox_11 = new JCheckBox("2500+");
        chckbxNewCheckBox_11.setBounds(123, 431, 97, 23);
        add(chckbxNewCheckBox_11);
        
        
        Name = new JLabel(Controller.getInstance().getCustomer().name);
        Name.setBounds(110, 27, 133, 14);
        add(Name);
        
        lblNewLabel = new JLabel("Name: ");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblNewLabel.setBounds(39, 26, 61, 14);
        add(lblNewLabel);
        
        lblCnic = new JLabel("CNIC: ");
        lblCnic.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblCnic.setBounds(310, 26, 61, 14);
        add(lblCnic);
        
        CNIC_label = new JLabel(Controller.getInstance().getCustomer().CNIC);
        CNIC_label.setBounds(381, 27, 133, 14);
        add(CNIC_label);
        
        lblContactDetails = new JLabel("Contact Details: ");
        lblContactDetails.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblContactDetails.setBounds(588, 26, 119, 14);
        add(lblContactDetails);
        
        Contact_label = new JLabel(Controller.getInstance().getCustomer().Contact);
        Contact_label.setBounds(711, 27, 133, 14);
        add(Contact_label);
        
        
      
        ///////////////////////////////////////////////////////////////////////////////////////////

        
        
        
        
        
        
        portfolioTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = portfolioTable.getSelectedRow();
                if (selectedRow != -1) {
                	String POF_ID = (String) portfolioTable.getValueAt(selectedRow, 0);
                    String selectedName = (String) portfolioTable.getValueAt(selectedRow, 1);
                   double selectedPricing = Double.parseDouble((String)portfolioTable .getValueAt(selectedRow, 2));
                    String selectedDescription = (String) portfolioTable.getValueAt(selectedRow, 3);
                  //  int selectedCapacity = (int) portfolioTable.getValueAt(selectedRow, 3);
                    int selectedCapacity = Integer.parseInt((String) portfolioTable.getValueAt(selectedRow, 4));

                    String selectedType = (String) portfolioTable.getValueAt(selectedRow, 5);
                    Controller.getInstance().getCustomer().selected_portfolio.portfolio_id = POF_ID ;
                    Controller.getInstance().getCustomer().selected_portfolio.Pof_name = selectedName ; 
                    System.out.println();
                    Controller.getInstance().getCustomer().selected_portfolio.capacity = selectedCapacity;
                    Controller.getInstance().getCustomer().selected_portfolio.description = selectedDescription ; 
                    Controller.getInstance().getCustomer().selected_portfolio.pricing = selectedPricing ; 
                    Controller.getInstance().getCustomer().selected_portfolio.Type = selectedType;
                    	
                    	
                    PlaceOrder placeOrder = new PlaceOrder();
                    placeOrder.setVisible(true);
                }
            }
        });

        
       // fetchedPortfolios = new ArrayList<>();  // Initialize here
    }
    
    
    
    

  

    
}
