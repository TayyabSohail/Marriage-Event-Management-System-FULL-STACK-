package proj;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdatePage extends JFrame {

    private DefaultTableModel tableModel;
    private JTextField textFieldVenId;
    private JTextField textFieldPricing;
    private JTextField textFieldDescription;
    private JTextField textFieldCapacity;
    private JTextField textFieldType;
    private int selectedRowIndex;

    public UpdatePage(DefaultTableModel tableModel, String venId, double pricing, String description, int capacity, String type, int selectedRowIndex) {
        this.tableModel = tableModel;
        this.selectedRowIndex = selectedRowIndex;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 400);
        JPanel contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2, 5, 5));

        JLabel lblUpdateData = new JLabel("Update Data");
        lblUpdateData.setFont(new Font("Arial", Font.BOLD, 18));

        JLabel lblVenId = new JLabel("Vendor ID:");
        textFieldVenId = new JTextField(venId);
        JLabel lblPricing = new JLabel("Pricing:");
        textFieldPricing = new JTextField(Double.toString(pricing));
        JLabel lblDescription = new JLabel("Description:");
        textFieldDescription = new JTextField(description);
        JLabel lblCapacity = new JLabel("Capacity:");
        textFieldCapacity = new JTextField(Integer.toString(capacity));
        JLabel lblType = new JLabel("Type:");
        textFieldType = new JTextField(type);

        inputPanel.add(lblVenId);
        inputPanel.add(textFieldVenId);
        inputPanel.add(lblPricing);
        inputPanel.add(textFieldPricing);
        inputPanel.add(lblDescription);
        inputPanel.add(textFieldDescription);
        inputPanel.add(lblCapacity);
        inputPanel.add(textFieldCapacity);
        inputPanel.add(lblType);
        inputPanel.add(textFieldType);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateDataInDatabase();
            }
        });

        contentPane.add(lblUpdateData, BorderLayout.NORTH);
        contentPane.add(inputPanel, BorderLayout.CENTER);
        contentPane.add(btnUpdate, BorderLayout.SOUTH);
    }

    private void updateDataInDatabase() {
        try {
            String venId = textFieldVenId.getText();
            double pricing = Double.parseDouble(textFieldPricing.getText());
            String description = textFieldDescription.getText();
            int capacity = Integer.parseInt(textFieldCapacity.getText());
            String type = textFieldType.getText();

            System.out.println(venId);
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
            String query = "UPDATE Portfolio SET Pricing=?, Description=?, Capacity=?, Type=? WHERE Ven_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            
            //Statement stmt =connection.createStatement();
            //String sql="INSERT INTO accounts(username, password, role) VALUES ('" + u + "', '" + pswd + "', '" + this.getRole() + "')";
            //stmt.executeUpdate(sql);
            
            preparedStatement.setDouble(1, pricing);
            preparedStatement.setString(2, description);
            preparedStatement.setInt(3, capacity);
            preparedStatement.setString(4, type);
            preparedStatement.setString(5, venId);

            preparedStatement.executeUpdate();

            // Update the data in the table model
            tableModel.setValueAt(venId, selectedRowIndex, 2);
            tableModel.setValueAt(pricing, selectedRowIndex, 3);
            tableModel.setValueAt(description, selectedRowIndex, 4);
            tableModel.setValueAt(capacity, selectedRowIndex, 5);
            tableModel.setValueAt(type, selectedRowIndex, 6);


            selectedRowIndex = -1;
            // After updating, you can close the update page
            dispose();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
