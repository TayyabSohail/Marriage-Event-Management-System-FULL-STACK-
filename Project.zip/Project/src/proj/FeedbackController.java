package proj;


public class FeedbackController {
 private Feedback feedback;

 public FeedbackController(String customerId, String orderId) {
     this.feedback = new Feedback(customerId, orderId);
 }

 public void submitFeedback(String comment, int stars) {
     feedback.saveFeedbackToDatabase(comment, stars);
     Controller.getInstance().getCustomer().Owd.emptyFeedback();
 }
}
