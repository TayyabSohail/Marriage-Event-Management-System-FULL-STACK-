package proj;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class WELCOME extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    WELCOME frame = new WELCOME();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public WELCOME() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 798, 600); // Increased the height of the frame
        contentPane = new JPanel();
        contentPane.setBackground(new Color(243, 151, 130)); // Set the background color
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add the heading "MARRY MANAGE" in black
        JLabel lblHeading = new JLabel("");
        lblHeading.setForeground(Color.BLACK);
        lblHeading.setFont(new Font("Arial", Font.BOLD, 30));
        lblHeading.setBounds(250, 50, 300, 40);
        contentPane.add(lblHeading);

        // Add the logo below the heading
        JLabel lblLogo = new JLabel("");
        lblLogo.setIcon(new ImageIcon("E:\\IMPORTED FROM C\\Desktop\\Project\\Image.jpeg")); // Replace with the actual path to your logo image
        lblLogo.setBounds(131, 57, 555, 318); // Adjusted the size of the logo to fit within the frame
        contentPane.add(lblLogo);

        JButton btnNewButton_2 = new JButton("LOGIN");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Login L = new Login();
                L.setVisible(true);
            }
        });
        btnNewButton_2.setForeground(new Color(0, 0, 0));
        btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 18));
        btnNewButton_2.setBackground(new Color(235, 231, 197));
        btnNewButton_2.setBounds(144, 457, 207, 40);
        contentPane.add(btnNewButton_2);

        JButton btnNewButton_1 = new JButton("REGISTER");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RegistrationForm R = new RegistrationForm();
                R.setVisible(true);
            }
        });
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 18));
        btnNewButton_1.setForeground(new Color(0, 0, 0));
        btnNewButton_1.setBackground(new Color(235, 231, 197));
        btnNewButton_1.setBounds(436, 457, 213, 40);
        contentPane.add(btnNewButton_1);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(144, 125, 456, 262);
        contentPane.add(lblNewLabel);
    }
}