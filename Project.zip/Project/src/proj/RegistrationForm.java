package proj;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;

public class RegistrationForm extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField nameField;
    private JTextField cnicField;
    private JTextField contactField;
    private JComboBox<String> userTypeDropdown;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    RegistrationForm frame = new RegistrationForm();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public RegistrationForm() {
        setType(Type.UTILITY);
        setTitle("REGISTRATION FORM");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 424);
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setForeground(new Color(255, 255, 255));
        panel.setBackground(new Color(243, 151, 130)); // Set the background color
        panel.setBounds(0, 0, 684, 89);
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("REGISTRATION");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 30));
        lblNewLabel.setForeground(new Color(0,0,0));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(150, 11, 364, 54);
        panel.add(lblNewLabel);

        nameField = new JTextField();
        nameField.setBounds(353, 140, 223, 26);
        getContentPane().add(nameField);
        nameField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("NAME");
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 13));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setBounds(226, 137, 77, 33);
        getContentPane().add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("CNIC");
        lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 13));
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2.setBounds(236, 174, 46, 26);
        getContentPane().add(lblNewLabel_2);

        cnicField = new JTextField();
        cnicField.setBounds(353, 174, 223, 26);
        getContentPane().add(cnicField);
        cnicField.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("CONTACT");
        lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 13));
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_3.setBounds(213, 211, 69, 26);
        getContentPane().add(lblNewLabel_3);

        contactField = new JTextField();
        contactField.setBounds(353, 211, 223, 26);
        getContentPane().add(contactField);
        contactField.setColumns(10);

        JLabel lblNewLabel_4 = new JLabel("USER TYPE");
        lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 13));
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_4.setBounds(213, 248, 69, 26);
        getContentPane().add(lblNewLabel_4);

        // Dropdown for User Type
        userTypeDropdown = new JComboBox<String>();
        userTypeDropdown.addItem("CUSTOMER");
        userTypeDropdown.addItem("VENDOR");
        userTypeDropdown.setBounds(353, 248, 223, 26);
        getContentPane().add(userTypeDropdown);

        JButton registrationButton = new JButton("REGISTER");
        registrationButton.setForeground(new Color(255, 255, 255));
        registrationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get values from text fields and dropdown
                String name = nameField.getText();
                String cnic = cnicField.getText();
                String contact = contactField.getText();
                String userType = (String) userTypeDropdown.getSelectedItem();

                // Perform registration logic (replace with your registration code)
                Register register = new Register();
                register.register(userType, name, cnic, contact);

                // Display registration success message (replace with your desired message)
                //JOptionPane.showMessageDialog(null, "Registration Successful");
            }
        });
        registrationButton.setFont(new Font("Arial", Font.PLAIN, 11));
        registrationButton.setBackground(new Color(0, 0, 0));
        registrationButton.setBounds(373, 293, 119, 33);
        getContentPane().add(registrationButton);
    }
}
