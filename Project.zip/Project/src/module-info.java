/**
 * 
 */
/**
 * 
 */
module project {
	requires java.sql;
	requires java.desktop;
}